package org.springframework.jersy.feign.core;

import feign.Feign;
import feign.jaxrs.JAXRSContract;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.FactoryBean;
import org.springframework.beans.factory.NoSuchBeanDefinitionException;
import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.EnvironmentAware;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.Environment;
import org.springframework.core.env.MutablePropertySources;
import org.springframework.core.env.PropertySource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.EncodedResource;
import org.springframework.core.io.support.PropertiesLoaderSupport;
import org.springframework.core.io.support.PropertiesLoaderUtils;
import org.springframework.jersy.feign.core.decoder.FastJsonDecoder;
import org.springframework.jersy.feign.core.encoder.FastJsonEncoder;
import org.springframework.jersy.feign.core.util.ReflectUtils;
import org.springframework.lang.Nullable;
import org.springframework.util.PropertyPlaceholderHelper;
import org.springframework.util.StringUtils;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.stream.Stream;

/**
 * @Author xiejs
 * @Description
 * @Date Created in 2018/8/24 19:20
 */
@Data
@Slf4j
public class RestFeignClientFactoryBean implements FactoryBean, EnvironmentAware, ApplicationContextAware {

    private final String placeholderPrefix = "${";

    private final String placeholderSuffix = "}";

    private ConfigurableEnvironment environment;

    /**
     * 引用环境变量中的配置值
     */
    private List<Properties> properties;

    private Class<?> targetType;

    private String beanName;

    private String prefixUrl;

    private Boolean singleton = Boolean.TRUE;

    private Boolean isSecure;

    /**
     * 替换Properties中的占位符
     */
    private final PropertyPlaceholderHelper helper = new PropertyPlaceholderHelper(placeholderPrefix, placeholderSuffix);

    @Override
    public void setEnvironment(Environment environment) {
        this.environment = (ConfigurableEnvironment) environment;
    }

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {

        PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer=null;

        try{
             propertySourcesPlaceholderConfigurer = applicationContext.getBean(PropertySourcesPlaceholderConfigurer.class);
        }catch (NoSuchBeanDefinitionException e){

            // ignore

        }

        if ( null != propertySourcesPlaceholderConfigurer ) {
            MutablePropertySources propertySources = (MutablePropertySources) propertySourcesPlaceholderConfigurer.getAppliedPropertySources();
            Iterator<PropertySource<?>> propertySourceIterator = propertySources.iterator();
            while (propertySourceIterator.hasNext()) {
                PropertySource<?> propertySource = propertySourceIterator.next();
                properties.add((Properties) propertySource.getSource());
            }

        }

        try {

            PropertiesLoaderSupport propertiesLoaderSupport = applicationContext.getBean(PropertyPlaceholderConfigurer.class);

            String fileEncoding=ReflectUtils.getFieldValue(PropertiesLoaderSupport.class,propertiesLoaderSupport,"fileEncoding");
            Resource[] resources=ReflectUtils.getFieldValue(PropertiesLoaderSupport.class,propertiesLoaderSupport,"locations");



            Properties prop=new Properties();

            Stream.of(resources).forEach(resource -> {
                try {
                    PropertiesLoaderUtils.fillProperties(prop,new EncodedResource(resource,fileEncoding));
                } catch (IOException e) {
                    log.error("failed to load properties,resources:{}",resources);
                }
            });

            properties.add(prop);

        }catch (NoSuchBeanDefinitionException e){

            // ignore

        }

    }

    @Nullable
    @Override
    public Object getObject() throws Exception {


        String actualPrefixUrl = resolvePlaceholders();


        if (isSecure) {

            if (actualPrefixUrl.startsWith("http://")) {
                StringUtils.replace(actualPrefixUrl, "http://", "https://");
            }

            if (!actualPrefixUrl.startsWith("http://") && !actualPrefixUrl.startsWith("https://")) {
                actualPrefixUrl = "https://" + actualPrefixUrl;
            }

        } else {

            if (actualPrefixUrl.startsWith("https://")) {
                StringUtils.replace(actualPrefixUrl, "https://", "http://");
            }

            if (!actualPrefixUrl.startsWith("http://") && !actualPrefixUrl.startsWith("https://")) {
                actualPrefixUrl = "http://" + actualPrefixUrl;
            }

        }


        Object proxy = Feign.builder()
                .encoder(new FastJsonEncoder())
                .decoder(new FastJsonDecoder())
                .contract(new JAXRSContract())
                .target(targetType, actualPrefixUrl);

        return proxy;
    }

    @Nullable
    @Override
    public Class<?> getObjectType() {
        return targetType;
    }

    @Override
    public boolean isSingleton() {
        return singleton;
    }

    /**
     * 解决占位符
     *
     * @return
     */
    private String resolvePlaceholders() {

        String actualPrefixUrl = environment.resolvePlaceholders(prefixUrl);

        if (containsPlaceholder(actualPrefixUrl)) {

            for (Properties prop : properties) {
                actualPrefixUrl = helper.replacePlaceholders(prefixUrl, prop);
                if (!containsPlaceholder(actualPrefixUrl)) {
                    return actualPrefixUrl;
                }
            }

        }

        return actualPrefixUrl;
    }


    private boolean containsPlaceholder(String str) {
        return str.contains(placeholderPrefix) && str.contains(placeholderSuffix) && !str.contains("#{");
    }


//    public static void main(String[] args) {
////        PropertiesLoaderUtils.fillProperties(
////                props, new EncodedResource(location, this.fileEncoding), this.propertiesPersister);
//
//
//
//
//
//        Field locations = ReflectionUtils.findField(RestFeignClientFactoryBean.class, "singleton");
//
//        ReflectionUtils.makeAccessible(locations);
//
//        Boolean resources = (Boolean) ReflectionUtils.getField(locations, new RestFeignClientFactoryBean());
//
//        PropertyPlaceholderHelper helper = new PropertyPlaceholderHelper("#{", "}");
//        MutablePropertySources propertySources = new MutablePropertySources();
//        Properties prop = new Properties();
//        prop.setProperty("aa", "aaaa111");
//        propertySources.addLast(new PropertiesPropertySource("test", prop));
//        propertySources.forEach(propertySource -> {
//            String s = helper.replacePlaceholders("http://#{aa}", (Properties) propertySource.getSource());
//            System.out.println(s);
//
//        });
//
//    }

}
