package org.springframework.jersy.feign.core.annotation;


import java.lang.annotation.*;

/**
 * @Author xiejs
 * @Description
 * @Date Created in 2018/8/21 17:21
 */
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface RestFeignClient {

    /**
     * client name
     * will be bean name
     * @see RestFeignClient#value()
     * name value must have one
     * @return
     */
    String name() default "";

    /**
     * client name
     * name value must have one
     * will be bean name
     * @see RestFeignClient#name()
     * @return
     */
    String value () default "";

    /**
     * start with http://
     * must be not null
     * <note>el express can be used eg:${}</note>
     */
    String url() default "";

    /**
     * if true, will invoke https://.. default http://....
     *
     */
    boolean isSecure() default false;

    /**
     * if true ,will return singleton bean
     * @return
     */
    boolean singleton() default true;

}
